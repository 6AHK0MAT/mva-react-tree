import React from 'react';
import './App.css';
import ReactTree from "./component/react-tree/react-tree";

function App() {
    return (
        <div>
            <ReactTree/>
        </div>
    );
}

export default App;
