module.exports = {
    module: 'Дерево',
    collapsed: false,
    children: [
        {
            module: 'Ветка 1',
            collapsed: true,
            children: [
                {
                    module: 'Лист 1.1',
                    leaf: true
                },
                {
                    module: 'Лист 1.2',
                    leaf: true
                },
                {
                    module: 'Лист 1.3',
                    leaf: true
                },
                {
                    module: 'Лист 1.4',
                    leaf: true
                }
            ]
        },
        {
            module: 'Ветка 2',
            collapsed: false,
            children: [
                {
                    module: 'Лист 2.1',
                    leaf: true
                },
                {
                    module: 'Лист 2.2',
                    leaf: true
                },
                {
                    module: 'Лист 2.3',
                    leaf: true
                }
            ]
        },
        {
            module: 'Ветка 3',
            collapsed: false,
            children: [
                {
                    module: 'Лист 3.1',
                    leaf: true
                },
                {
                    module: 'Лист 3.2',
                    leaf: true
                },
                {
                    module: 'Лист 3.3',
                    leaf: true
                },
                {
                    module: 'Лист 3.4',
                    leaf: true
                }
            ]
        }
    ]
};
